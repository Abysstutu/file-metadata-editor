"""File property metadata editor."""
